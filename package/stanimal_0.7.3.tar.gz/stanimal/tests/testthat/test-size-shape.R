set.seed(11)
n <- 40
size <- rnorm(n)
Y4 <- cbind(a = size + rnorm(n, sd = 0.3),
            b = 2 * size + rnorm(n, sd = 0.3),
            c = -size + rnorm(n, sd = 0.3),
            d = size + rnorm(n, sd = 0.5))
colnames(Y4) <- c("a", "b", "c", "d")

names_mat <- function(var, k) {
  sprintf(paste0(var, "[%d,%d]"), rep(seq_len(k), k), rep(seq_len(k), each = k))
}

test_that("size_shape returns size plus orthogonal shape axes", {
  ss <- size_shape(Y4)
  expect_s3_class(ss, "size_shape")
  expect_equal(colnames(ss$scores), c("size", "shape1", "shape2", "shape3"))
  expect_equal(ss$raw_traits, colnames(Y4))
  expect_equal(dim(ss$loadings), c(4L, 4L))
  expect_equal(unname(ss$scores[, "size"]), unname(rowMeans(Y4)))
  expect_equal(cor(ss$scores[, -1]), diag(3), ignore_attr = TRUE, tolerance = 1e-8)
  expect_output(print(ss), "size_shape")
})

test_that("size and shape reconstruct the traits up to their means", {
  ss <- size_shape(Y4)
  reconstructed <- ss$scores %*% t(ss$loadings)
  expect_equal(scale(reconstructed, scale = FALSE), scale(Y4, scale = FALSE),
               ignore_attr = TRUE)
})

test_that("n_shape keeps fewer shape axes", {
  ss <- size_shape(Y4, n_shape = 2)
  expect_equal(colnames(ss$scores), c("size", "shape1", "shape2"))
  expect_equal(dim(ss$loadings), c(4L, 3L))
  expect_equal(unname(ss$loadings[, "size"]), rep(1, 4))
})

test_that("size_shape validates its input", {
  expect_error(size_shape(Y4[, 1]), "at least two traits")
  expect_error(size_shape(matrix("a", 5, 2)), "numeric")
  expect_error(size_shape(Y4, n_shape = 0), "n_shape")
  expect_error(size_shape(Y4, n_shape = 4), "n_shape")
  expect_error(size_shape(Y4, n_shape = 1.5), "n_shape")
})

test_that("back_transform maps G and E and recomputes corrG and h2", {
  ss <- size_shape(Y4)
  k <- 4
  G <- matrix(0.3, k, k); diag(G) <- 1
  E <- matrix(0.1, k, k); diag(E) <- 2
  m <- cbind(matrix(rep(as.vector(G), 3), 3, byrow = TRUE),
             matrix(rep(as.vector(E), 3), 3, byrow = TRUE))
  colnames(m) <- c(names_mat("G", k), names_mat("E", k))

  post <- back_transform(m, ss)
  B <- ss$loadings
  exp_G <- unname(B %*% G %*% t(B))
  exp_E <- unname(B %*% E %*% t(B))
  exp_P <- exp_G + exp_E

  expect_s3_class(post, "size_shape_draws")
  expect_named(post, c("G", "E", "P", "corrG", "corrP", "h2", "traits"))
  expect_equal(dim(post$G), c(k, k, 3L))
  expect_identical(dimnames(post$G), list(ss$raw_traits, ss$raw_traits, NULL))
  expect_equal(unname(post$G[, , 1]), exp_G)
  expect_equal(unname(post$E[, , 1]), exp_E)
  expect_equal(unname(post$P[, , 1]), exp_P)
  expect_equal(unname(post$corrG[, , 1]), unname(cov2cor(exp_G)))
  expect_equal(unname(post$corrP[, , 1]), unname(cov2cor(exp_P)))
  expect_equal(unname(post$h2[, 1]), unname(diag(exp_G) / diag(exp_P)))
  expect_output(print(post), "size_shape_draws")
})

test_that("pc1_variance_share detects a single gradient", {
  set.seed(7)
  gradient <- rnorm(50)
  correlated <- cbind(a = gradient + rnorm(50, sd = 0.2),
                      b = 2 * gradient + rnorm(50, sd = 0.2),
                      c = -gradient + rnorm(50, sd = 0.2))
  expect_gt(pc1_variance_share(correlated), 0.95)
  expect_lt(pc1_variance_share(matrix(rnorm(150), 50, 3)), 0.7)
  expect_equal(pc1_variance_share(rnorm(50)), 1)
  expect_error(pc1_variance_share(matrix("a", 5, 2)), "numeric")
  expect_error(pc1_variance_share(cbind(1:5, rep(1, 5))), "must vary")
  expect_error(pc1_variance_share(matrix(0, 5, 3)), "must vary")
})

test_that("animal_design warns about a dominant principal component", {
  set.seed(8)
  gradient <- rnorm(30)
  dominant <- data.frame(a = gradient + rnorm(30, sd = 0.1),
                         b = 2 * gradient + rnorm(30, sd = 0.1),
                         c = -gradient + rnorm(30, sd = 0.1))
  expect_warning(animal_design(cbind(a, b, c) ~ 1, dominant), "size_shape")
  independent <- data.frame(a = rnorm(30), b = rnorm(30), c = rnorm(30))
  expect_silent(animal_design(cbind(a, b, c) ~ 1, independent))
})

test_that("back_transform handles a phenotypic fit (P only)", {
  ss <- size_shape(Y4)
  k <- 4
  P <- matrix(0.2, k, k); diag(P) <- 1.5
  m <- matrix(rep(as.vector(P), 2), 2, byrow = TRUE)
  colnames(m) <- names_mat("P", k)

  post <- back_transform(m, ss)
  B <- ss$loadings
  exp_P <- unname(B %*% P %*% t(B))

  expect_named(post, c("P", "corrP", "sigma_P", "traits"))
  expect_equal(dim(post$P), c(k, k, 2L))
  expect_equal(dim(post$sigma_P), c(k, 2L))
  expect_equal(unname(post$P[, , 1]), exp_P)
  expect_equal(unname(post$corrP[, , 1]), unname(cov2cor(exp_P)))
  expect_equal(unname(post$sigma_P[, 1]), sqrt(diag(exp_P)))
})

test_that("back_transform works with fewer shape axes than traits", {
  ss <- size_shape(Y4, n_shape = 2)
  k_model <- ncol(ss$loadings)
  k <- nrow(ss$loadings)
  P <- matrix(0.2, k_model, k_model); diag(P) <- 1.5
  m <- matrix(rep(as.vector(P), 2), 2, byrow = TRUE)
  colnames(m) <- names_mat("P", k_model)

  post <- back_transform(m, ss)
  expect_equal(dim(post$P), c(k, k, 2L))
  expect_identical(dimnames(post$P), list(ss$raw_traits, ss$raw_traits, NULL))
  expect_equal(unname(post$P[, , 1]), unname(ss$loadings %*% P %*% t(ss$loadings)))
})

test_that("back_transform validates its input", {
  ss <- size_shape(Y4)
  expect_error(back_transform(matrix(0, 1, 1), list()), "`size_shape` object")
  m <- matrix(0, 2, 2, dimnames = list(NULL, c("G[1,1]", "E[1,1]")))
  expect_error(back_transform(m, ss), "must contain G and E")
  expect_error(back_transform(matrix(0, 2, 2), ss), "named matrix")
})

test_that("to_draws_list reshapes the arrays into posterior draws", {
  ss <- size_shape(Y4)
  k <- 4
  G <- matrix(0.3, k, k); diag(G) <- 1
  E <- matrix(0.1, k, k); diag(E) <- 2
  m <- cbind(matrix(rep(as.vector(G), 3), 3, byrow = TRUE),
             matrix(rep(as.vector(E), 3), 3, byrow = TRUE))
  colnames(m) <- c(names_mat("G", k), names_mat("E", k))
  post <- back_transform(m, ss)

  draws <- to_draws_list(post)
  expect_named(draws, c("G", "E", "P", "corrG", "corrP", "h2"))
  expect_identical(attr(draws, "traits"), ss$raw_traits)
  expect_s3_class(draws$G, "draws_matrix")
  expect_equal(dim(draws$G), c(3L, k * k))
  expect_identical(posterior::variables(draws$G), names_mat("G", k))
  expect_equal(as.numeric(as.matrix(draws$G)[1, ]), as.numeric(post$G[, , 1]))

  # correlations appear once per pair, above the diagonal
  pairs <- which(upper.tri(diag(k)), arr.ind = TRUE)
  pairs <- pairs[order(pairs[, 1], pairs[, 2]), , drop = FALSE]
  expect_identical(posterior::variables(draws$corrG),
                   sprintf("corrG[%d,%d]", pairs[, 1], pairs[, 2]))
  expect_equal(as.numeric(as.matrix(draws$corrG)[1, ]),
               as.numeric(post$corrG[cbind(pairs[, 1], pairs[, 2], rep(1L, nrow(pairs)))]))

  expect_identical(posterior::variables(draws$h2), sprintf("h2[%d]", seq_len(k)))
  expect_equal(as.numeric(as.matrix(draws$h2)[1, ]), as.numeric(post$h2[, 1]))

  # the draws objects can be summarised on their own or bound together
  expect_s3_class(posterior::summarise_draws(draws$corrG), "data.frame")
  # bind_draws() takes the draws objects as unnamed arguments
  expect_s3_class(do.call(posterior::bind_draws, unname(draws)), "draws_matrix")
})

test_that("to_draws_list handles a phenotypic fit and validates its input", {
  ss <- size_shape(Y4)
  k <- 4
  P <- matrix(0.2, k, k); diag(P) <- 1.5
  m <- matrix(rep(as.vector(P), 2), 2, byrow = TRUE)
  colnames(m) <- names_mat("P", k)
  post <- back_transform(m, ss)

  draws <- to_draws_list(post)
  expect_named(draws, c("P", "corrP", "sigma_P"))
  expect_identical(posterior::variables(draws$sigma_P),
                   sprintf("sigma_P[%d]", seq_len(k)))
  expect_equal(as.numeric(as.matrix(draws$sigma_P)[1, ]), as.numeric(post$sigma_P[, 1]))
  expect_error(to_draws_list(list()), "size_shape_draws")
})

# Incomplete trait records.
#
# Size is a mean of all the traits and shape is a difference between them, so a
# row with a gap has neither until the gap is filled. The fill is the
# conditional mean under a multivariate normal whose mean and covariance are
# estimated from the data, which leaves a complete response untouched.

# 200 individuals on the same size gradient. The 40 rows of `Y4` are too few
# for the gap tests: their sample covariance is itself noisy, so a completed
# estimate could not be told apart from one that had gone wrong.
set.seed(21)
big_size <- rnorm(200)
Ybig <- cbind(a = big_size + rnorm(200, sd = 0.3),
              b = 2 * big_size + rnorm(200, sd = 0.3),
              c = -big_size + rnorm(200, sd = 0.3),
              d = big_size + rnorm(200, sd = 0.5))

gappy <- function(Y, n_gaps, seed) {
  original <- Y
  set.seed(seed)
  Y[sample(length(Y), n_gaps)] <- NA
  # a row with nothing observed is an error by design, so keep one value
  blank <- rowSums(is.na(Y)) == ncol(Y)
  Y[blank, 1] <- original[blank, 1]
  Y
}

test_that("the gap completion recovers the covariance of the complete data", {
  Y <- gappy(Ybig, 64, seed = 22)
  expect_gt(sum(is.na(Y)), 50)
  fit <- stanimal:::.normal_em(Y)
  expect_lt(max(abs(fit$mean - colMeans(Ybig))), 0.05)
  # covariances are compared as a relative error: these entries differ by an
  # order of magnitude, so an absolute difference means nothing on its own
  truth <- stats::cov(Ybig)
  expect_lt(max(abs(fit$covariance - truth) / abs(truth)), 0.08)
  # observed entries are never replaced
  completed <- stanimal:::.conditional_gaps(Y, fit$mean, fit$covariance)$Y
  expect_equal(completed[!is.na(Y)], Y[!is.na(Y)])
  expect_false(anyNA(completed))
})

test_that("size_shape completes the gaps and says so", {
  Y <- gappy(Ybig, 64, seed = 23)
  complete <- size_shape(Ybig)
  ss <- size_shape(Y)

  expect_equal(ss$gaps, sum(is.na(Y)))
  expect_s3_class(ss, "size_shape")
  expect_equal(dim(ss$scores), dim(complete$scores))
  # only the completed rows carry a spread, and the spread depends on which
  # traits are missing rather than on the values
  gappy_rows <- which(rowSums(is.na(Y)) > 0)
  expect_true(all(ss$scores_sd[-gappy_rows, ] == 0))
  expect_true(all(ss$scores_sd[gappy_rows, ] > 0))
  # the axes are estimated from all the individuals, so they hardly move. Signs
  # are arbitrary, which is why the comparison is on magnitudes.
  expect_lt(max(abs(abs(ss$loadings) - abs(complete$loadings))), 0.05)
  # and the scores stay close to the ones the same mice would have had. The last
  # shape axis carries the least variance and is the last to stabilise.
  expect_gt(min(diag(stats::cor(ss$scores, complete$scores))[1:3]), 0.95)
  expect_output(print(ss), "completed")
})

test_that("a complete response is left alone", {
  ss <- size_shape(Y4)
  expect_equal(ss$gaps, 0L)
  expect_null(ss$scores_sd)
  expect_output(print(ss), "complete")
})

test_that("the more traits are missing, the wider the completed score", {
  one <- Ybig
  one[1, 2] <- NA
  three <- Ybig
  three[1, c(1, 3, 4)] <- NA
  expect_lt(sum(size_shape(one)$scores_sd[1, ]),
            sum(size_shape(three)$scores_sd[1, ]))
  expect_equal(unname(size_shape(one)$scores_sd[2, ]), rep(0, 4))
})

test_that("gaps that cannot be completed are an error", {
  blank <- Y4
  blank[3, ] <- NA
  expect_error(size_shape(blank), "at least one observed trait")

  no_trait <- Y4
  no_trait[, "d"] <- NA
  expect_error(size_shape(no_trait), "at least two observed values")

  # the first half of the mice have no `a`, the second half no `b`
  never <- Y4
  never[1:20, "a"] <- NA
  never[21:40, "b"] <- NA
  expect_error(size_shape(never), "never measured on the same individual")

  expect_error(size_shape(matrix(Inf, 5, 3)), "infinite")
})

test_that("pc1_variance_share takes an incomplete response", {
  Y <- gappy(Ybig, 64, seed = 24)
  expect_equal(pc1_variance_share(Y), pc1_variance_share(Ybig), tolerance = 0.02)
  expect_error(pc1_variance_share(matrix(NA_real_, 5, 3)), "observed trait")
})

test_that("plot_G_ellipses drops the individuals with a trait missing", {
  k <- 4
  G <- matrix(0.2, k, k); diag(G) <- 1
  m <- matrix(rep(as.vector(G), 3), 3, byrow = TRUE)
  colnames(m) <- names_mat("G", k)
  Y <- Y4
  Y[c(1, 5), "a"] <- NA
  p <- plot_G_ellipses(m, Y)
  expect_s3_class(p, "ggplot")
})

test_that("animal_design keeps a response with gaps and still diagnoses it", {
  set.seed(9)
  gradient <- rnorm(30)
  dominant <- data.frame(a = gradient + rnorm(30, sd = 0.1),
                         b = 2 * gradient + rnorm(30, sd = 0.1),
                         c = -gradient + rnorm(30, sd = 0.1))
  dominant$a[5] <- NA
  expect_warning(design <- animal_design(cbind(a, b, c) ~ 1, dominant),
                 "size_shape")
  expect_true(is.na(design$Y[5, 1]))
})
